package com.example.tvs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class dashboard_admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.dashboard_admin);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView img1 = findViewById(R.id.admindashboard_vehicles);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this,admin_addcar.class);
                startActivity(intent);
            }
        });

        ImageView img2 = findViewById(R.id.admindashboard_violations);

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this,admin_addviolation.class);
                startActivity(intent);
            }
        });

        ImageView img3 = findViewById(R.id.admindashboard_driver);

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this,admin_adddriver.class);
                startActivity(intent);
            }
        });

        ImageView img4 = findViewById(R.id.admindashboard_citations);

        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this, citations.class);
                startActivity(intent);
            }
        });

        ImageView img5 = findViewById(R.id.admindashboard_payment);

        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this, payments.class);
                startActivity(intent);
            }
        });

        ImageView img7= findViewById(R.id.logout);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dashboard_admin.this,logout.class);
                startActivity(intent);
            }
        });
    }
}