package com.example.tvs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_addviolation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.admin_addviolation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView img1 = findViewById(R.id.Violation_home);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,dashboard_admin.class);
                startActivity(intent);
            }
        });

        ImageView img2 = findViewById(R.id.Violation_vehicles);

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,admin_addviolation.class);
                startActivity(intent);
            }
        });

        ImageView img3 = findViewById(R.id.Violation_Citations);

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,citations.class);
                startActivity(intent);
            }
        });

        ImageView img4 = findViewById(R.id.Violation_Payment);

        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,payments.class);
                startActivity(intent);
            }
        });

        ImageView img5 = findViewById(R.id.image_rectangle2);

        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,admin_addnewviolation.class);
                startActivity(intent);
            }
        });

        ImageView img6= findViewById(R.id.Violation_Profile);
        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,admin_adddriver.class);
                startActivity(intent);
            }
        });

        ImageView img7= findViewById(R.id.logout);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_addviolation.this,logout.class);
                startActivity(intent);
            }
        });


    }
}