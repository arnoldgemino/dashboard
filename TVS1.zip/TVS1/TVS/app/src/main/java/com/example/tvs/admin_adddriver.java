package com.example.tvs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_adddriver extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.admin_adddriver);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView img7 = findViewById(R.id.adddriver);
        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,admin_addnewdriver.class);
                startActivity(intent);
            }
        });
        ImageView img1 = findViewById(R.id.Driver_violation);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,admin_addviolation.class);
                startActivity(intent);
            }
        });
        ImageView img2 = findViewById(R.id.Driver_citations);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,citations.class);
                startActivity(intent);
            }
        });
        ImageView img3 = findViewById(R.id.Driver_payments);
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,payments.class);
                startActivity(intent);
            }
        });
        ImageView img4= findViewById(R.id.Driver_home);
        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,dashboard_admin.class);
                startActivity(intent);
            }
        });
        ImageView img5= findViewById(R.id.Driver_vehicle);
        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,admin_addcar.class);
                startActivity(intent);
            }
        });

        ImageView img8= findViewById(R.id.logout);
        img8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_adddriver.this,logout.class);
                startActivity(intent);
            }
        });

    }
}